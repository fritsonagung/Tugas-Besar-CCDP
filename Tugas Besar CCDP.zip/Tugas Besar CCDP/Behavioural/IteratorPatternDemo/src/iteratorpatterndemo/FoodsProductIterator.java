package iteratorpatterndemo;

/*
    @Author : Fritson Agung Julians Ayomi - 10116076
*/

public interface FoodsProductIterator {
    public boolean hasMore();
    public Object getNext();
}
