package iteratorpatterndemo;

/*
    @Author : Fritson Agung Julians Ayomi - 10116076
*/

public interface Products {
     FoodsProductIterator getIterator();
}
