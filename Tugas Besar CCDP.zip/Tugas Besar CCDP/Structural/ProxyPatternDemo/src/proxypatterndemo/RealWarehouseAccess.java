package proxypatterndemo;

/*
    @Author : Fritson Agung Julians Ayomi - 10116076
*/

public class RealWarehouseAccess implements ShopWarehouseAccess{
  
    @Override
    public void grantWarehouseAccess() {
       System.out.println("Accessing the warehouse");  
    }
    
}
