/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractfactory;

/**
 *
 * @author USER
 */
public interface Meja {
  public void JumlahKaki();
  public void Tinggi();
  public void Nama();
  public void Berat();
  public void Panjang();
  public void Lebar();
  public void Harga();
}
